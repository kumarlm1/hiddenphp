package com.mijio.jioshop;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.hiddenapp.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class SearchActivity extends AppCompatActivity {

    EditText edSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        getSupportActionBar().hide();

        edSearch = findViewById(R.id.edSearch);
    }

    public void btnHomeClicked(View view) {
        Intent i = new Intent(this, LandingActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
                Intent.FLAG_ACTIVITY_CLEAR_TASK |
                Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        finish();
    }

    public void btnSearchClicked(View view) {
        final String num = edSearch.getText().toString().trim();

        if(num.isEmpty()){
            edSearch.setError("Please fill out this field");
            return;
        }

        if( num.length() < 10 ){
            edSearch.setError("mobile number should be 10 digits");
            return;
        }

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please wait...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        String url = "https://pubgflippo.xyz/fhhhh/api/search-order";
        RequestQueue queue  = Volley.newRequestQueue(this);
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        progressDialog.dismiss();
                        try {
                            JSONObject object = new JSONObject(response);
                            int code = object.getInt("code");

                            if( code == 200){
                                // found

                                String data = object.getString("data");
                                Intent intent = new Intent(SearchActivity.this, SearchSuccessActivity.class);
                                intent.putExtra("DATA", data);
                                startActivity(intent);

                            }
                            else {
                                // not found
                                Intent intent = new Intent(SearchActivity.this, SearchResultActivity.class);
                                startActivity(intent);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<>();
                map.put("mobile", num);
                return map;
            }
        };
        queue.add(request);


    }
}