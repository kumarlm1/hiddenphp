package com.mijio.jioshop;

public class Order {
    String orderId;
    String name;
    String phone;
    String dt;
    String status;

    public Order() {
    }

    public Order(String orderId, String name, String mobile, String dt, String status) {
        this.orderId = orderId;
        this.name = name;
        this.phone = mobile;
        this.dt = dt;
        this.status = status;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDt() {
        return dt;
    }

    public void setDt(String dt) {
        this.dt = dt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
