package com.mijio.jioshop;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.hiddenapp.R;

public class FormActivity extends AppCompatActivity {

    EditText edName, edMobile, edAddress, edCity, edPinCode;
    Spinner spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);
        getSupportActionBar().hide();

        edName = findViewById(R.id.edName);
        edMobile = findViewById(R.id.edMobile);
        edAddress = findViewById(R.id.edAddress);
        edCity = findViewById(R.id.edCity);
        edPinCode = findViewById(R.id.edPinCode);
        spinner = findViewById(R.id.spinner);
    }

    public void backBtnPressed(View view) {
        finish();
    }

    public void continueClicked(View view) {

        String name = edName.getText().toString().trim();

        if( name.isEmpty()){
            edName.setError("Please fill out this field");
            return;
        }

        String mobile = edMobile.getText().toString().trim();

        if( mobile.isEmpty()){
            edMobile.setError("Please fill out this field");
            return;
        }

        String address = edAddress.getText().toString().trim();

        if( address.isEmpty()){
            edAddress.setError("Please fill out this field");
            return;
        }

        String city = edCity.getText().toString().trim();

        if( city.isEmpty()){
            edCity.setError("Please fill out this field");
            return;
        }


        String pinCode = edPinCode.getText().toString().trim();

        if( pinCode.isEmpty()){
            edPinCode.setError("Please fill out this field");
            return;
        }

        if(spinner.getSelectedItem().toString().equals("- Select State-")){
            Toast.makeText(this, "Please Select State from list", Toast.LENGTH_SHORT).show();
            return;
        }

        if( mobile.length() < 10 ){
            Toast.makeText(this, "Mobile Number should be 10 digits", Toast.LENGTH_SHORT).show();
            return;
        }

        if( pinCode.length() < 6 ){
            Toast.makeText(this, "Pin Code should be 6 digits", Toast.LENGTH_SHORT).show();
            return;
        }


        Intent intent = new Intent(FormActivity.this, PaymentActivity.class);
        intent.putExtra("NAME", name);
        intent.putExtra("MOBILE", mobile);
        intent.putExtra("ADDRESS", address);
        intent.putExtra("CITY", city);
        intent.putExtra("STATE", spinner.getSelectedItem().toString());
        intent.putExtra("PINCODE", pinCode);

        startActivity(intent);
    }

    public void hamburgerClick(View view) {
        startActivity(new Intent(this, SearchActivity.class));
    }

    public void btnHomeClicked(View view) {
        Intent i = new Intent(this, LandingActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
                Intent.FLAG_ACTIVITY_CLEAR_TASK |
                Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        finish();
    }
}