package com.mijio.jioshop;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.hiddenapp.R;

public class MyCartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_cart);
        getSupportActionBar().hide();
    }

    public void continueClicked(View view) {
        startActivity(new Intent(MyCartActivity.this, FormActivity.class));
    }

    public void backBtnPressed(View view) {
        finish();
    }

    public void hamburgerClick(View view) {
        startActivity(new Intent(this, SearchActivity.class));
    }

    public void btnHomeClicked(View view) {
        finish();
    }
}