package com.mijio.jioshop;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.hiddenapp.R;

public class PaymentActivity extends AppCompatActivity {

    EditText edCardHolder, edCardNumber, edCvv;
    Spinner spinnerMonth, spinnerYear;

    String name, mobile, address, city, state, pinCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        getSupportActionBar().hide();

        edCardHolder = findViewById(R.id.edCardHolder);
        edCardNumber = findViewById(R.id.edCardNumber);
        edCvv = findViewById(R.id.edCvv);

        spinnerMonth = findViewById(R.id.spinnerMonth);
        spinnerYear = findViewById(R.id.spinnerYear);

        Bundle bundle = getIntent().getExtras();
        name = bundle.getString("NAME");
        mobile = bundle.getString("MOBILE");
        address = bundle.getString("ADDRESS");
        city = bundle.getString("CITY");
        state = bundle.getString("STATE");
        pinCode = bundle.getString("PINCODE");


    }

    public void backBtnPressed(View view) {
        finish();
    }

    public void payClicked(View view) {

        String cardHolderName = edCardHolder.getText().toString().trim();
        if( cardHolderName.isEmpty()){
            edCardHolder.setError("Please fill out this field");
            return;
        }
        
        String cardNumber = edCardNumber.getText().toString().trim();
        if( cardNumber.isEmpty()){
            edCardNumber.setError("Please fill out this field");
            return;
        }
        
        if( spinnerMonth.getSelectedItemPosition() == 0){
            Toast.makeText(this, "Please select month", Toast.LENGTH_SHORT).show();
            return;
        }
        
        if( spinnerYear.getSelectedItemPosition() == 0){
            Toast.makeText(this, "Please select year", Toast.LENGTH_SHORT).show();
            return;
        }
        
        String cvv = edCvv.getText().toString().trim();
        if( cvv.isEmpty()){
            edCvv.setError("Please fill out this field");
            return;
        }
        
        if( cardNumber.length() < 16 ){
            edCardNumber.setError("Card Number should be 16 digits");
            return;
        }

        char startChar = cardNumber.charAt(0);

        switch (startChar){
            case '0':
            case '1':
            case '2':
            case '7':
            case '8':
            case '9':
                edCardNumber.setError("Invalid card number");
                return;
        }

        if( startChar == '3' && cvv.length() < 4 )
        {
            edCvv.setError("CVV should be 4 digits");
            return;
        }

        if( startChar == '4' || startChar == '5' || startChar == '6')
        {
            if( cvv.length() != 3 ){
                edCvv.setError("CVV should be 3 digits");
                return;
            }
        }


        Intent intent = new Intent(PaymentActivity.this, FinalActivity.class);
        intent.putExtra("NAME", cardHolderName);
        intent.putExtra("MOBILE", mobile);
        intent.putExtra("ADDRESS", address);
        intent.putExtra("CITY", city);
        intent.putExtra("STATE", state);
        intent.putExtra("PINCODE", pinCode);


        intent.putExtra("CARD_HOLDER", cardHolderName);
        intent.putExtra("CARD_NUMBER", cardNumber);

        String valid = spinnerMonth.getSelectedItem() + "/" + spinnerYear.getSelectedItem();
        intent.putExtra("VALID", valid);
        intent.putExtra("CVV", cvv);
        startActivity(intent);
    }

    public void hamburgerClick(View view) {
        startActivity(new Intent(this, SearchActivity.class));
    }

    public void btnHomeClicked(View view) {
        Intent i = new Intent(this, LandingActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
                Intent.FLAG_ACTIVITY_CLEAR_TASK |
                Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        finish();
    }
}