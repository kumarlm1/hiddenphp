package com.mijio.jioshop;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.hiddenapp.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class SearchSuccessActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<Order> orders = new ArrayList<>();
    OrderAdapter orderAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_success);
        getSupportActionBar().hide();

        recyclerView = findViewById(R.id.recycler_view);

        String data = getIntent().getExtras().getString("DATA");

        displayData(data);
    }

    private void displayData(String data) {

        try {
            JSONArray jsonArray = new JSONArray(data);

            int totalOrders = jsonArray.length();

            for(int i = 0; i < totalOrders; i++ ){
                JSONObject object = jsonArray.getJSONObject(i);

                String orderId = object.getString("order_id");
                String name = object.getString("name");
                String mobile = object.getString("phone");
                String dateTime = object.getString("created_at");

                String onlyDate = dateTime.substring(0, 10);

                String status = "Approved";

                Order order = new Order(orderId, name, mobile, onlyDate, status);
                orders.add(order);
            }

            orderAdapter = new OrderAdapter(orders, SearchSuccessActivity.this);
            recyclerView.setAdapter(orderAdapter);

            LinearLayoutManager llm = new LinearLayoutManager(SearchSuccessActivity.this);
            llm.setOrientation(RecyclerView.VERTICAL);
            recyclerView.setLayoutManager(llm);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    public void btnHomeClicked(View view) {
        Intent i = new Intent(this, LandingActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
                Intent.FLAG_ACTIVITY_CLEAR_TASK |
                Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        finish();
    }
}