package com.mijio.jioshop;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.hiddenapp.R;

import java.util.ArrayList;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderVH> {

    ArrayList<Order> orders;
    Context context;

    public OrderAdapter(ArrayList<Order> orders, Context context) {
        this.orders = orders;
        this.context = context;
    }

    @NonNull
    @Override
    public OrderVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.row_order, parent, false);
        return new OrderVH(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderVH holder, int position) {

        Order order = orders.get(position);
        holder.tvOrderId.setText(order.getOrderId());
        holder.tvCustomerName.setText(order.getName());
        holder.tvPhoneNumber.setText(order.getPhone());
        holder.tvOrderDate.setText(order.getDt());
        holder.tvOrderStatus.setText(order.getStatus());
    }

    @Override
    public int getItemCount() {
        return orders.size();
    }

    class OrderVH extends RecyclerView.ViewHolder {

        TextView tvOrderId, tvCustomerName, tvPhoneNumber, tvOrderDate, tvOrderStatus;

        public OrderVH(@NonNull View itemView) {
            super(itemView);

            tvOrderId = itemView.findViewById(R.id.tvOrderId);
            tvCustomerName = itemView.findViewById(R.id.tvCustomerName);
            tvPhoneNumber = itemView.findViewById(R.id.tvPhoneNumber);
            tvOrderDate = itemView.findViewById(R.id.tvOrderDate);
            tvOrderStatus = itemView.findViewById(R.id.tvOrderStatus);
        }
    }
}
